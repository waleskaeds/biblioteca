import java.util.ArrayList;
import java.util.Scanner;

public abstract class Pessoa {
    static Scanner sc = new Scanner(System.in);
    public static ArrayList<Pessoa> listaPessoas = new ArrayList<>();

    private String nome, sobrenome;
    private long cpf;
    private int senha;
    public static int numCadastro;

    public Pessoa(String nome, String sobrenome, long cpf, int senha){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.cpf = cpf;
        this.senha = senha;

        numCadastro++;
    }

    public static void cadastrar(){
        System.out.println("\n1. Palestrante" +
                "\n2. Aluno");
        int escolha = sc.nextInt();

        System.out.println("CADASTRO");
        System.out.println("Nome: ");
        String nome = sc.next();
        System.out.println("Sobrenome: ");
        String sobrenome = sc.next();
        System.out.println("CPF: ");
        long cpf = sc.nextLong();
        System.out.println("Senha: ");
        int senha = sc.nextInt();

        do{
            if(escolha == 1){
                System.out.println("Grau de escolaridade: ");
                String escolaridade = sc.next();
                System.out.println("Área de atuação: ");
                String area = sc.next();
                listaPessoas.add(new Palestrante(nome, sobrenome, cpf, senha, escolaridade, area));
                System.out.println("Palestrante Cadastrado!");
            } else {
                System.out.println("Curso: ");
                String curso = sc.next();
                listaPessoas.add(new Aluno(nome, sobrenome, cpf, senha, curso));
                System.out.println("Aluno Cadastrado!");
            }
        } while (escolha != 1 && escolha !=2);


    }

    public static void login(){
        System.out.println("\nLOGIN");
        System.out.println("Número de Cadastro: ");
         int numCadastro = sc.nextInt();
        System.out.println("Senha: ");
        int senha = sc.nextInt();

        for (Pessoa i: listaPessoas
             ) {

        }
    }

    public static void listar(){
        for (int i = 0; i < listaPessoas.size(); i++) {
            System.out.println(listaPessoas.get(i).toString());
        }
    }

    @Override
    public String toString() {
        return "Pessoa" +
                "\nnome: '" + nome +
                "\nsobrenome: '" + sobrenome +
                "\ncpf: " + cpf;
    }
}
