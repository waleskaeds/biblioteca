public class Horário extends Evento{
    private int hora, minuto;


    public Horário(String palestrante, String tema, int data, int horario, String local) {
        super(palestrante, tema, data, horario, local);
    }
}
