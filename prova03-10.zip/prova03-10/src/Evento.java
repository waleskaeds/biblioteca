import java.util.ArrayList;
import java.util.Scanner;

public class Evento {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Evento> listaEventos = new ArrayList<>();

    private String tema, local, palestrante;
    private int data, horario;

    public Evento(String palestrante, String tema, int data, int horario, String local) {
        this.palestrante = palestrante;
        this.tema = tema;
        this.data = data;
        this.horario = horario;
        this.local = local;

    }

    public static void cadastrarEvento(){
        System.out.println("CADASTRO DE EVENTO");
        System.out.println("\nPalestrante: ");
        String palestrante = sc.next();
        System.out.println("\nTema: ");
        String tema = sc.next();
        System.out.println("\nData: ");
        int data = sc.nextInt();
        System.out.println("\nHorário: ");
        int horario = sc.nextInt();
        System.out.println("\nLocal: ");
        String local = sc.next();

        listaEventos.add(new Evento(palestrante, tema, data, horario, local));
        System.out.println("Evento Cadastrado!");
    }


    public static void listarEventosPalestrante(){
    System.out.print("Eventos do palestrante: ");
    String palestranteEsc = sc.next();
        for (int i = 0; i < listaEventos.size(); i++) {
            if (palestranteEsc == listaEventos.get(i).getPalestrante()) {
                listaEventos.toString();
                break;
            }
        }
    }

    public static void listarEventosAluno(){
        System.out.print("Aluno cadastrado nos eventos: ");
        String alunoEsc = sc.next();
        for (int i = 0; i < listaEventos.size(); i++) {
            if (alunoEsc == listaEventos.get(i).getPalestrante()) {
                listaEventos.toString();
                break;
            }
        }
    }


    public static void listarEventos(){
        for (int i = 0; i < listaEventos.size(); i++) {
            System.out.println(listaEventos.get(i).toString());
        }
    }

    @Override
    public String toString() {
        return "Palestrante: "+ palestrante +
                "\nTema: " + tema +
                "\nData" + data +
                "\nHorário: "+ horario +
                "\nLocal: "+ local;
    }

    public String getPalestrante() {
        return palestrante;
    }
}
