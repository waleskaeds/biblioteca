public class Data extends Evento{
    int dia, mes, ano;


    public Data(String palestrante, String tema, int data, int horario, String local) {
        super(palestrante, tema, data, horario, local);
    }
}
