public class Palestrante extends Pessoa{

    private String escolaridade, área;

    public Palestrante(String nome, String sobrenome, long cpf, int senha,
                       String escolaridade, String area){
        super(nome, sobrenome, cpf, senha);
        this.escolaridade = escolaridade;
        this.área = area;
    }
}
