public class Aluno extends Pessoa{
    private String curso;

    public Aluno(String nome, String sobrenome, long cpf, int senha,
                 String curso) {
        super(nome, sobrenome, cpf, senha);
        this.curso = curso;
    }
}
