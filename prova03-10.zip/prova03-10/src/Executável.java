import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class Executável {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("1. Cadastrar" +
                "\n2. Login");
        int entrar = sc.nextInt();
        switch (entrar){
            case 1:
                Pessoa.cadastrar();
            case 2:
                System.out.println("Entrar em:" +
                        "\n1. Palestrante" +
                        "\n2. Aluno");
                int logar = sc.nextInt();
                Pessoa.login();
                switch(logar) {
                    case 1: //palestrante
                        menuPalestrante();
                        break; // fim do palestrante
                }
/*
                case 2: // aluno
                    menuAluno();
                    menu = sc.nextInt();
                    switch(menu){
                        case 1:
                            Evento.participarEvento();
                            break;
                        case 2:
                            Evento.listarEventosAluno();
                            break;
                        case 3:
                            Evento.listarEventos();
                            break;
                        case 4:
                            System.exit(0);
                    }
            }*/

                break;
        }
    }

    public static void menuAluno(){
        System.out.println("MENU" +
                    "\n1. Participar do Evento"
                +"\n2. Listar Eventos"
                +"\n3. Todos os Eventos"
                +"\n4. Sair");
    }

    public static void menuPalestrante(){
        System.out.println("\nMENU" +
                "\n1. Cadastrar Evento"
                +"\n2. Listar Eventos"
                +"\n3. Todos os Eventos"
                +"\n4. Sair");
        int menu = sc.nextInt();

        switch (menu) {
            case 1:
                Evento.cadastrarEvento();
                menuPalestrante();
                break;
            case 2:
                Evento.listarEventosPalestrante();
                menuPalestrante();
                break;
            case 3:
                Evento.listarEventos();
                menuPalestrante();
                break;
            case 4:
                System.exit(0);
        }
    }

}
